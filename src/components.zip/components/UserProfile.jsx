import React from 'react';

const UserProfile = () => {
  return (
    <div>
      <h2>User Profile</h2>
      <p>View and update your profile here.</p>
    </div>
  );
};

export default UserProfile;