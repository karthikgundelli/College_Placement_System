import React from 'react';

const RecentDrives = () => {
  return (
    <div>
      <h2>Recent Drives</h2>
      <p>List of recent placement drives will be displayed here.</p>
    </div>
  );
};

export default RecentDrives;